let guess = 0;
let min = 1;
let max = 20;

let target = Math.random() * (max - min + 1);
target = Math.floor(target);

console.log(target);
while(guess !== target){
    guess = Number(prompt("guess a number(whole numbers please)"));
    if(guess < target){
        alert("higher");
    }else if(guess > target){
        alert("lower");
    }else{
        alert("you got it!");
    }
    
}